# coding: utf-8

from setuptools import setup, find_packages  # noqa: H301

NAME = "volcengine_sample"
VERSION = "1.0.0"

REQUIRES = [
    "volcengine-python-sdk>=5.0.9"
]

setup(
    name=NAME,
    version=VERSION,
    install_requires=REQUIRES,
    packages=find_packages(),
    include_package_data=True,
    description='Volcengine Sample for Python',
)