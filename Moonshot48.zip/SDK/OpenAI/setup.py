# coding: utf-8

from setuptools import setup, find_packages  # noqa: H301

NAME = "ark_openai_sample"
VERSION = "1.0.0"

REQUIRES = [
    "openai"
]

setup(
    name=NAME,
    version=VERSION,
    install_requires=REQUIRES,
    packages=find_packages(),
    include_package_data=True,
    description='Ark openai Sample for Python',
)