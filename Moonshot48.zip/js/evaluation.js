// 评价结果相关功能

// 检查用户是否登录
function checkLogin() {
    const user = localStorage.getItem('user');
    if (!user) {
        // 用户未登录，跳转到登录页面
        window.location.href = 'index.html';
    }
}

// 调用AI服务生成评价
async function generateEvaluationWithAI() {
    const interviewResult = localStorage.getItem('interviewResult');
    const identity = localStorage.getItem('identity');
    const profile = localStorage.getItem('profile');
    
    // 准备AI请求参数
    const messages = [
        {
            role: 'system',
            content: '你是一个专业的面试评价专家，负责对求职者的面试表现进行评价和分析。'
        },
        {
            role: 'user',
            content: `请对以下面试情况进行评价：\n` +
                    `面试结果：${interviewResult === 'pass' ? '通过' : '不通过'}\n` +
                    `身份：${identity === 'interviewer' ? '面试官' : '选手'}\n` +
                    `个人资料：${profile ? JSON.parse(profile).nickname : '未知'}\n` +
                    `请提供：1. 评分（0-100分）2. 面试评价 3. 改进建议（至少3条）4. 总体评价`
        }
    ];
    
    try {
        // 调用AI服务（使用OpenAI API格式）
        const response = await fetch('https://ark.cn-beijing.volces.com/api/v3/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + '5a9b89c0-7c96-4d1f-8f75-1ac08a407b1c' // 真实的API Key
            },
            body: JSON.stringify({
                model: 'doubao-seed-1-6-flash-250828',
                messages: messages
            })
        });
        
        if (response.ok) {
            const data = await response.json();
            const aiResponse = data.choices[0].message.content;
            
            // 解析AI响应
            parseAIResponse(aiResponse);
        } else {
            // API调用失败，使用模拟数据
            generateMockEvaluation();
        }
    } catch (error) {
        console.error('AI服务调用失败:', error);
        // 出错时使用模拟数据
        generateMockEvaluation();
    }
}

// 生成模拟评价（当AI服务不可用时）
function generateMockEvaluation() {
    const interviewResult = localStorage.getItem('interviewResult');
    
    // 根据面试结果生成评价
    let score, feedback, suggestions, overallFeedback;
    
    if (interviewResult === 'pass') {
        // 通过的评价
        score = Math.floor(Math.random() * 10) + 90;
        feedback = '您的面试表现非常出色，回答问题思路清晰，逻辑严密，展现了良好的专业素养和沟通能力。';
        suggestions = [
            '继续保持自信的表现风格',
            '可以更深入地准备一些技术细节问题',
            '在团队合作方面可以提供更多具体案例'
        ];
        overallFeedback = '总体来说，您的面试表现优秀，具备较强的专业能力和综合素质，符合岗位要求。';
    } else {
        // 不通过的评价
        score = Math.floor(Math.random() * 20) + 70;
        feedback = '您的面试表现基本合格，但在某些方面还有提升空间。回答问题时思路不够清晰，专业知识掌握不够扎实。';
        suggestions = [
            '加强专业知识的学习和巩固',
            '提高逻辑思维和表达能力',
            '多参加模拟面试，积累面试经验',
            '准备更多具体的项目案例'
        ];
        overallFeedback = '总体来说，您的面试表现有待提高，需要在专业知识、表达能力等方面加强训练。';
    }
    
    // 显示评价
    document.getElementById('score-display').textContent = score + '分';
    document.getElementById('feedback-text').textContent = feedback;
    
    // 显示AI建议
    const suggestionsContainer = document.getElementById('ai-suggestions');
    const suggestionsList = document.createElement('ul');
    suggestions.forEach(suggestion => {
        const li = document.createElement('li');
        li.textContent = suggestion;
        suggestionsList.appendChild(li);
    });
    suggestionsContainer.appendChild(suggestionsList);
    
    // 显示总体评价
    document.getElementById('overall-feedback').textContent = overallFeedback;
}

// 解析AI响应
function parseAIResponse(response) {
    // 简单解析，实际使用时可能需要更复杂的解析逻辑
    // 假设AI响应格式为：
    // 评分：95分
    // 面试评价：...
    // 改进建议：
    // 1. ...
    // 2. ...
    // 3. ...
    // 总体评价：...
    
    const lines = response.split('\n');
    let score = 85;
    let feedback = '';
    let suggestions = [];
    let overallFeedback = '';
    
    // 提取评分
    const scoreLine = lines.find(line => line.includes('评分：'));
    if (scoreLine) {
        score = parseInt(scoreLine.match(/\d+/)[0]);
    }
    
    // 提取面试评价
    const feedbackStart = lines.findIndex(line => line.includes('面试评价：'));
    if (feedbackStart !== -1) {
        for (let i = feedbackStart + 1; i < lines.length; i++) {
            if (lines[i].includes('改进建议：')) break;
            feedback += lines[i] + ' ';
        }
    }
    
    // 提取改进建议
    const suggestionsStart = lines.findIndex(line => line.includes('改进建议：'));
    if (suggestionsStart !== -1) {
        for (let i = suggestionsStart + 1; i < lines.length; i++) {
            if (lines[i].includes('总体评价：')) break;
            if (lines[i].trim()) {
                suggestions.push(lines[i].replace(/^\d+\.\s*/, ''));
            }
        }
    }
    
    // 提取总体评价
    const overallStart = lines.findIndex(line => line.includes('总体评价：'));
    if (overallStart !== -1) {
        for (let i = overallStart + 1; i < lines.length; i++) {
            overallFeedback += lines[i] + ' ';
        }
    }
    
    // 如果解析失败，使用默认值
    if (!feedback) {
        feedback = '您的面试表现良好，展现了一定的专业素养和沟通能力。';
    }
    
    if (suggestions.length === 0) {
        suggestions = [
            '继续保持自信的表现风格',
            '可以更深入地准备一些技术细节问题',
            '在团队合作方面可以提供更多具体案例'
        ];
    }
    
    if (!overallFeedback) {
        overallFeedback = '总体来说，您的面试表现合格，具备基本的专业能力和综合素质。';
    }
    
    // 显示评价
    document.getElementById('score-display').textContent = score + '分';
    document.getElementById('feedback-text').textContent = feedback;
    
    // 显示AI建议
    const suggestionsContainer = document.getElementById('ai-suggestions');
    const suggestionsList = document.createElement('ul');
    suggestions.forEach(suggestion => {
        const li = document.createElement('li');
        li.textContent = suggestion;
        suggestionsList.appendChild(li);
    });
    suggestionsContainer.appendChild(suggestionsList);
    
    // 显示总体评价
    document.getElementById('overall-feedback').textContent = overallFeedback;
}

// 生成AI评价
function generateEvaluation() {
    generateEvaluationWithAI();
}

// 设置继续按钮
function setupContinueButton() {
    const continueButton = document.getElementById('continue-button');
    if (continueButton) {
        continueButton.addEventListener('click', () => {
            // 跳转到匹配等待页面，重新开始匹配
            window.location.href = 'waiting.html';
        });
    }
}

// 初始化评价结果页面
function initEvaluation() {
    checkLogin();
    generateEvaluation();
    setupContinueButton();
}

// 页面加载完成后初始化
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initEvaluation);
} else {
    initEvaluation();
}
