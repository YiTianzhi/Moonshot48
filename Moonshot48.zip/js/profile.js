// 个人资料相关功能

// 检查用户是否登录
function checkLogin() {
    const user = localStorage.getItem('user');
    if (!user) {
        // 用户未登录，跳转到登录页面
        window.location.href = 'index.html';
    }
}

// 保存个人资料
function setupProfileSubmit() {
    const submitButton = document.getElementById('submit-profile');
    if (submitButton) {
        submitButton.addEventListener('click', () => {
            const profile = {
                nickname: document.getElementById('nickname').value,
                gender: document.getElementById('gender').value,
                age: document.getElementById('age').value,
                education: document.getElementById('education').value,
                workExperience: document.getElementById('work-experience').value,
                projectExperience: document.getElementById('project-experience').value,
                skills: document.getElementById('skills').value,
                achievements: document.getElementById('achievements').value
            };

            // 验证必填字段
            if (!profile.nickname) {
                alert('请填写昵称');
                return;
            }

            // 存储个人资料到localStorage（实际项目中应该发送到服务器）
            localStorage.setItem('profile', JSON.stringify(profile));
            alert('个人资料提交成功！');
            
            // 跳转到匹配等待页面
            window.location.href = 'waiting.html';
        });
    }
}

// 加载个人资料（如果有）
function loadProfile() {
    const profile = localStorage.getItem('profile');
    if (profile) {
        const parsedProfile = JSON.parse(profile);
        document.getElementById('nickname').value = parsedProfile.nickname || '';
        document.getElementById('gender').value = parsedProfile.gender || '';
        document.getElementById('age').value = parsedProfile.age || '';
        document.getElementById('education').value = parsedProfile.education || '';
        document.getElementById('work-experience').value = parsedProfile.workExperience || '';
        document.getElementById('project-experience').value = parsedProfile.projectExperience || '';
        document.getElementById('skills').value = parsedProfile.skills || '';
        document.getElementById('achievements').value = parsedProfile.achievements || '';
    }
}

// 初始化个人资料页面
function initProfile() {
    checkLogin();
    loadProfile();
    setupProfileSubmit();
}

// 页面加载完成后初始化
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initProfile);
} else {
    initProfile();
}