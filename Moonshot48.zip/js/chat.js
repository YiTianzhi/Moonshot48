// 面试聊天室相关功能

// 检查用户是否登录
function checkLogin() {
    const user = localStorage.getItem('user');
    if (!user) {
        // 用户未登录，跳转到登录页面
        window.location.href = 'index.html';
    }
}

// 检查是否有身份信息
function checkIdentity() {
    const identity = localStorage.getItem('identity');
    if (!identity) {
        // 没有身份信息，跳转到匹配等待页面
        window.location.href = 'waiting.html';
    }
}

// 设置身份标签
function setupIdentityTag() {
    const identity = localStorage.getItem('identity');
    const identityTag = document.getElementById('identity-tag');
    
    if (identity === 'interviewer') {
        identityTag.textContent = '面试官';
        identityTag.classList.add('interviewer');
    } else {
        identityTag.textContent = '选手';
        identityTag.classList.add('candidate');
    }
}

// 显示/隐藏简历侧边栏
function setupResumeSidebar() {
    const identity = localStorage.getItem('identity');
    const resumeSidebar = document.getElementById('resume-sidebar');
    
    if (identity === 'interviewer') {
        // 面试官可见简历
        resumeSidebar.style.display = 'block';
        loadResume();
    } else {
        // 选手不可见简历
        resumeSidebar.style.display = 'none';
    }
}

// 加载简历信息（模拟）
function loadResume() {
    // 模拟选手简历数据
    const resume = {
        basic: '张三，男，25岁',
        education: '北京大学，计算机科学，2019-2023',
        work: '某科技公司，前端工程师，2023-至今',
        project: '电商网站开发，负责前端页面实现',
        skills: 'JavaScript, React, CSS, HTML',
        achievements: '获得校奖学金，带领团队完成重要项目'
    };
    
    // 显示简历信息
    document.getElementById('resume-basic').textContent = resume.basic;
    document.getElementById('resume-education').textContent = resume.education;
    document.getElementById('resume-work').textContent = resume.work;
    document.getElementById('resume-project').textContent = resume.project;
    document.getElementById('resume-skills').textContent = resume.skills;
    document.getElementById('resume-achievements').textContent = resume.achievements;
}

// 发送消息
function setupMessageSending() {
    const sendButton = document.getElementById('send-button');
    const messageInput = document.getElementById('message-input');
    const messagesContainer = document.getElementById('messages-container');
    const identity = localStorage.getItem('identity');
    
    // 发送按钮点击事件
    sendButton.addEventListener('click', sendMessage);
    
    // 输入框回车事件
    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
    
    function sendMessage() {
        const messageText = messageInput.value.trim();
        if (messageText) {
            // 创建消息元素
            const messageDiv = document.createElement('div');
            messageDiv.classList.add('message', identity);
            
            const messageBubble = document.createElement('div');
            messageBubble.classList.add('message-bubble', identity);
            messageBubble.textContent = messageText;
            
            const messageTime = document.createElement('div');
            messageTime.classList.add('message-time');
            messageTime.textContent = new Date().toLocaleTimeString();
            
            messageDiv.appendChild(messageBubble);
            messageDiv.appendChild(messageTime);
            messagesContainer.appendChild(messageDiv);
            
            // 清空输入框
            messageInput.value = '';
            
            // 滚动到底部
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
            
            // 模拟对方回复（仅用于演示）
            setTimeout(() => {
                simulateReply();
            }, 1000);
        }
    }
    
    // 模拟对方回复
    function simulateReply() {
        const replies = [
            '好的，我理解了。',
            '这个问题很有意思。',
            '我需要思考一下。',
            '是的，我有相关经验。',
            '可以详细说明一下吗？'
        ];
        
        const randomReply = replies[Math.floor(Math.random() * replies.length)];
        const otherIdentity = identity === 'interviewer' ? 'candidate' : 'interviewer';
        
        // 创建回复消息元素
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message', otherIdentity);
        
        const messageBubble = document.createElement('div');
        messageBubble.classList.add('message-bubble', otherIdentity);
        messageBubble.textContent = randomReply;
        
        const messageTime = document.createElement('div');
        messageTime.classList.add('message-time');
        messageTime.textContent = new Date().toLocaleTimeString();
        
        messageDiv.appendChild(messageBubble);
        messageDiv.appendChild(messageTime);
        messagesContainer.appendChild(messageDiv);
        
        // 滚动到底部
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
}

// 设置面试控制按钮
function setupInterviewControls() {
    const passButton = document.getElementById('pass-button');
    const failButton = document.getElementById('fail-button');
    const endButton = document.getElementById('end-button');
    
    // 通过按钮点击事件
    passButton.addEventListener('click', () => {
        localStorage.setItem('interviewResult', 'pass');
        alert('您已选择通过');
    });
    
    // 不通过按钮点击事件
    failButton.addEventListener('click', () => {
        localStorage.setItem('interviewResult', 'fail');
        alert('您已选择不通过');
    });
    
    // 结束面试按钮点击事件
    endButton.addEventListener('click', () => {
        if (confirm('确定要结束面试吗？')) {
            // 跳转到评价结果页面
            window.location.href = 'evaluation.html';
        }
    });
}

// 初始化面试聊天室
function initChat() {
    checkLogin();
    checkIdentity();
    setupIdentityTag();
    setupResumeSidebar();
    setupMessageSending();
    setupInterviewControls();
    
    // 添加系统消息
    const messagesContainer = document.getElementById('messages-container');
    const systemMessage = document.createElement('div');
    systemMessage.style.textAlign = 'center';
    systemMessage.style.color = '#666';
    systemMessage.style.fontSize = '14px';
    systemMessage.style.margin = '10px 0';
    systemMessage.textContent = '面试开始，AI正在记录面试过程...';
    messagesContainer.appendChild(systemMessage);
}

// 页面加载完成后初始化
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initChat);
} else {
    initChat();
}
