// 匹配等待相关功能

// 检查用户是否登录
function checkLogin() {
    const user = localStorage.getItem('user');
    if (!user) {
        // 用户未登录，跳转到登录页面
        window.location.href = 'index.html';
    }
}

// 检查是否有个人资料
function checkProfile() {
    const profile = localStorage.getItem('profile');
    if (!profile) {
        // 没有个人资料，跳转到个人资料页面
        window.location.href = 'profile.html';
    }
}

// 模拟匹配过程
function simulateMatching() {
    // 随机匹配时间（3-8秒）
    const matchTime = Math.floor(Math.random() * 5000) + 3000;
    
    setTimeout(() => {
        // 匹配成功，分配身份（面试官或选手）
        const identity = Math.random() > 0.5 ? 'interviewer' : 'candidate';
        localStorage.setItem('identity', identity);
        
        // 跳转到面试聊天室页面
        window.location.href = 'chat.html';
    }, matchTime);
}

// 取消匹配
function setupCancelButton() {
    const cancelButton = document.getElementById('cancel-button');
    if (cancelButton) {
        cancelButton.addEventListener('click', () => {
            if (confirm('确定要取消匹配吗？')) {
                // 跳转到个人资料页面
                window.location.href = 'profile.html';
            }
        });
    }
}

// 初始化匹配等待页面
function initWaiting() {
    checkLogin();
    checkProfile();
    simulateMatching();
    setupCancelButton();
}

// 页面加载完成后初始化
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initWaiting);
} else {
    initWaiting();
}