// 认证相关功能

// 标签页切换功能
function setupTabSwitching() {
    const loginTab = document.getElementById('login-tab');
    const registerTab = document.getElementById('register-tab');
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');

    if (loginTab && registerTab && loginForm && registerForm) {
        loginTab.addEventListener('click', () => {
            loginTab.classList.add('active');
            registerTab.classList.remove('active');
            loginForm.style.display = 'block';
            registerForm.style.display = 'none';
        });

        registerTab.addEventListener('click', () => {
            registerTab.classList.add('active');
            loginTab.classList.remove('active');
            registerForm.style.display = 'block';
            loginForm.style.display = 'none';
        });
    }
}

// 注册功能
function setupRegister() {
    const registerButton = document.getElementById('register-button');
    if (registerButton) {
        registerButton.addEventListener('click', () => {
            const username = document.getElementById('register-username').value;
            const password = document.getElementById('register-password').value;

            if (username && password) {
                // 存储用户信息到localStorage（实际项目中应该发送到服务器）
                localStorage.setItem('user', JSON.stringify({ username, password }));
                alert('注册成功！请登录');
                // 切换到登录表单
                document.getElementById('login-tab').click();
            } else {
                alert('请填写完整的注册信息');
            }
        });
    }
}

// 登录功能
function setupLogin() {
    const loginButton = document.getElementById('login-button');
    if (loginButton) {
        loginButton.addEventListener('click', () => {
            const username = document.getElementById('login-username').value;
            const password = document.getElementById('login-password').value;

            // 从localStorage获取用户信息（实际项目中应该发送到服务器验证）
            const storedUser = localStorage.getItem('user');
            if (storedUser) {
                const user = JSON.parse(storedUser);
                if (user.username === username && user.password === password) {
                    // 登录成功，跳转到个人资料页面
                    window.location.href = 'profile.html';
                } else {
                    alert('用户名或密码错误');
                }
            } else {
                alert('用户不存在，请先注册');
            }
        });
    }
}

// 初始化认证功能
function initAuth() {
    setupTabSwitching();
    setupRegister();
    setupLogin();
}

// 页面加载完成后初始化
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAuth);
} else {
    initAuth();
}